package com.id.servlet;
import java.sql.*;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;  
import com.mysql.jdbc.Statement;  
public class User{ 
	public static String User_id;
	public static String Password;
	public static String Email;
	public static int flag;
	public static String getUser_id(){
		return User_id;
	}
	public static void setUser_id(String User_ids){
		User_id=User_ids;
	}
	public static String getPassword(){
		return Password;
	}
	public static void setPassword(String Passwords){
		Password=Passwords;
	}
	public static String getEmail(){
		return Email;
	}
	public static void setEmail(String Emails){
		Email=Emails;
	}
	public static int getFlag(){
		return flag;
	}
	public static void setFlag(int flags){
		flag=flags;
	}
public static void getInfo(){  
	try{
        String url="jdbc:mysql://localhost/webclass";//database  
        String user="root";
        String pwd="00";//password 
        Class.forName("com.mysql.jdbc.Driver").newInstance();               
        Connection conn=(Connection) DriverManager.getConnection(url,user,pwd);             
        Statement stmt=(Statement) ((java.sql.Connection) conn).createStatement();  
        String sql;  
        sql="select * from User_info ";   
        ResultSet rs = (ResultSet) stmt.executeQuery(sql);   //���������  
        
        while (rs.next())  
        {  
          String User_id1 = rs.getString("User_id"); 
          String Password1 = rs.getString("Password"); 
          if(User_id.equals(User_id1)){
        	  if(Password.equals(Password1)){
        		  flag=1;
        		   conn.close();
        		  break;
        		 }
          }
          
  
       conn.close(); 
      }
}catch (Exception ex)
{
    return ;
}

}
public static int PostInfo(String user_id,String password,String email){
	int a =0;
	try{
        String url="jdbc:mysql://localhost/webclass";//database  
        String user="root";
        String pwd="00";//password 
        Class.forName("com.mysql.jdbc.Driver").newInstance();               
        Connection conn=(Connection) DriverManager.getConnection(url,user,pwd);             
        Statement stmt=(Statement) ((java.sql.Connection) conn).createStatement();  
        String sql;  
        sql="insert into User_info(User_id,Password,Email) values ("+user_id+","+password+","+email+")";   
       a=stmt.executeUpdate(sql);
        conn.close(); 
      }catch (Exception ex)
{
    	 
    	   return 0;
}
	 if(a==1)  return 1;
	  else return 0;
}
}